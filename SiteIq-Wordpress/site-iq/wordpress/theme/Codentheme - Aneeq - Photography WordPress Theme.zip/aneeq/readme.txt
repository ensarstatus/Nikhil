﻿Aneeq WordPress theme is a fully responsive theme that looks great on any devices including iPad, iPhone or any other mobile device, you can also Check Out Free Theme Demo https://demo.awplife.com/aneeq/

== Installation ==
Manual installation:

1. Upload the `aneeq` folder to the `/wp-content/themes/` directory

Activiation and Use

1. Activate the Theme through the 'Themes' menu in WordPress
2. See Customizer-> Aneeq Theme Options to change theme specific options

== Custom Logo ==
This theme supports custom logo for the header part. 
You can change or remove it from Customizer -> Aneeq Theme Options -> Header Settings.

== Default image ==
Default image from theme screenshot

Slider Images

URL : https://pixabay.com/en/meeting-construction-business-2284501/
Soucre : https://pixabay.com/
License: CC0 Public Domain

== Theme Notes ==
About the theme in the following link.

You can drop your queries in our contact form in the following link.

== Additional Notes ==
The theme is released for free under the terms of the GNU General Public License version 2
and some parts under their respective licenses.
In general words, feel free and encouraged to use, modify and redistribute this theme however you like.
You may remove any copyright references (unless required by third party components) and crediting is not necessary.
The theme is offered free of charge. If someone asked money for it, someone just tricked you.

== Supported Browser ==
Mozilla Firefox, Google Chrome, Safari, IE 10, 9, 8, 7


== Changelog ==

Aneeq: Version 1.3.3
* Enhancements: none
* Bug Fix: none
* Update: footer widget updated, style css indented

Aneeq: Version 1.3.2
* Enhancements: Testes Wordpress Version 5.2.2
* Bug Fix: Yes
* Additional changes: Yes

Feature Enhancements: Version 1.3.1
* Enhancements: Testes Wordpress Version 5.2.2
* Bug Fix: Yes
* Additional changes: Yes

Aneeq: Version 1.2.21
* Enhancements: requirments imporved
* Bug Fix: Yes
* Additional changes: Yes

Aneeq: Version 1.2.20
* Enhancements: requirments imporved
* Bug Fix: Yes
* Additional changes: Yes

Aneeq: Version 1.2.19
* Enhancements: requirments imporved
* Bug Fix: Yes
* Additional changes: Yes

Aneeq: Version 1.2.18
* Enhancements: requirments imporved
* Bug Fix: none
* Additional changes: none

Aneeq: Version 1.2.17
* Enhancements: requirments imporved
* Bug Fix: Yes
* Additional changes: yes

Aneeq: Version 1.2.16
* Enhancements: requirments imporved
* Bug Fix: Yes
* Additional changes: yes

Aneeq: Version 1.2.15
* Enhancements: requirments imporved
* Bug Fix: Yes
* Additional changes: yes

Aneeq: Version 1.2.14
* Enhancements: requirments imporved
* Bug Fix: none
* Additional changes: yes

Aneeq: Version 1.2.13
* Enhancements: requirments imporved
* Bug Fix: Yes, bullets manage
* Additional changes: None

Aneeq: Version 1.2.12
* Enhancements: requirments imporved
* Bug Fix: none
* Additional changes: yes


== Resources ==
Aneeq WordPress Theme, Copyright 2017 A WP Life
Aneeq is distributed under the terms of the GNU GPL

Flash Theme bundles the following third-party resources:

Bootstrap v3.3.5 (http://getbootstrap.com)
Copyright 2011-2015 Twitter, Inc.
Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
normalize.css v3.0.3 | MIT License | github.com/necolas/normalize.css

Font Awesome icon font, Copyright © 2015, Dave Gandy,
Font License: SIL OFL 1.1, http://scripts.sil.org/OFL
Code License: MIT License, http://www.opensource.org/licenses/MIT
Source: http://fontawesome.io/

Owl Carousal, Copyright (c) 2014 Owl
Modified work Copyright 2016-2018 David Deutsch
License: MIT License, http://www.opensource.org/licenses/MIT
Source: https://owlcarousel2.github.io/OwlCarousel2/